%{
#include <iostream>
#include <string>
#include <cstdio>
#include <cstring>
#include <cstdlib>

extern int yylex();
extern int num_linea;
void yyerror(const char *s);

/* ════════════════════════════
   NODO — AST y CST
   ════════════════════════════ */
struct Nodo {
    std::string etiqueta;
    Nodo *izq, *der, *tercero;
    Nodo(std::string et, Nodo *i = nullptr, Nodo *d = nullptr, Nodo *t = nullptr)
        : etiqueta(et), izq(i), der(d), tercero(t) {}
};

void imprimirAST(Nodo *n, std::string prefijo = "", bool esUltimo = true) {
    if (!n) return;
    std::cout << prefijo << (esUltimo ? "└── " : "├── ") << n->etiqueta << "\n";
    std::string np = prefijo + (esUltimo ? "    " : "│   ");
    int hijos = (n->izq?1:0) + (n->der?1:0) + (n->tercero?1:0);
    int idx = 0;
    if (n->izq)     { idx++; imprimirAST(n->izq,     np, idx==hijos); }
    if (n->der)     { idx++; imprimirAST(n->der,     np, idx==hijos); }
    if (n->tercero) { idx++; imprimirAST(n->tercero, np, idx==hijos); }
}

void imprimirCST(Nodo *n, std::string prefijo = "", bool esUltimo = true) {
    if (!n) return;
    std::cout << prefijo << (esUltimo ? "└── " : "├── ")
              << "\033[1;36m" << n->etiqueta << "\033[0m\n";
    std::string np = prefijo + (esUltimo ? "    " : "│   ");
    int hijos = (n->izq?1:0) + (n->der?1:0) + (n->tercero?1:0);
    int idx = 0;
    if (n->izq)     { idx++; imprimirCST(n->izq,     np, idx==hijos); }
    if (n->der)     { idx++; imprimirCST(n->der,     np, idx==hijos); }
    if (n->tercero) { idx++; imprimirCST(n->tercero, np, idx==hijos); }
}

/* ════════════════════════════
   VARIABLES
   ════════════════════════════ */
#define MAX_VARS 100
char var_nombres[MAX_VARS][50];
double var_valores[MAX_VARS];
int num_vars = 0;

int existe_var(const char *nombre) {
    for (int i = 0; i < num_vars; i++)
        if (std::string(var_nombres[i]) == nombre) return 1;
    return 0;
}

double obtener_var(const char *nombre) {
    if (!existe_var(nombre)) {
        std::cerr << "ERROR LOGICO en linea " << num_linea
                  << ": variable '" << nombre << "' no declarada\n";
        return 0;
    }
    for (int i = 0; i < num_vars; i++)
        if (std::string(var_nombres[i]) == nombre)
            return var_valores[i];
    return 0;
}

void guardar_var(const char *nombre, double valor) {
    for (int i = 0; i < num_vars; i++) {
        if (std::string(var_nombres[i]) == nombre) {
            var_valores[i] = valor;
            return;
        }
    }
    strcpy(var_nombres[num_vars], nombre);
    var_valores[num_vars] = valor;
    num_vars++;
}

void declarar_var(const char *nombre) {
    if (existe_var(nombre)) {
        std::cerr << "ERROR LOGICO en linea " << num_linea
                  << ": variable '" << nombre << "' ya declarada\n";
        return;
    }
    strcpy(var_nombres[num_vars], nombre);
    var_valores[num_vars] = 0;
    num_vars++;
}

void yyerror(const char *s) {
    std::cerr << "\n\033[1;31mERROR SINTACTICO en linea " << num_linea
              << ": " << s << "\033[0m\n";
    std::cerr << "  Revisa: ';' al final, parentesis sin cerrar, "
              << "o instruccion incompleta\n\n";
}
%}

%union {
    double num;
    char  *str;
    struct Nodo *nodo;
}

%token <num> NUM
%token <str> ID TEXTO
%token SI MOSTRAR DATOINGRESADO SALIDA ENTRADA
%token TENTERO TDECIMAL
%token LE GE EQ NE LT GT

%type <nodo> expr instruccion cond

%left '+' '-'
%left '*' '/'

%%

programa:
    | programa instruccion
        {
            if ($2) {
                std::cout << "\n\033[1;33m--- AST (Arbol Sintactico Abstracto) ---\033[0m\n";
                imprimirAST($2);
                std::cout << "\n\033[1;36m--- CST (Arbol Sintactico Concreto)  ---\033[0m\n";
                imprimirCST($2);
                std::cout << "\n";
            }
        }
;

instruccion:

    TENTERO ID ';'
        {
            declarar_var($2);
            $$ = new Nodo("declaracion entero: " + std::string($2),
                          nullptr, nullptr,
                          new Nodo("token: ';'"));
        }

    | TDECIMAL ID ';'
        {
            declarar_var($2);
            $$ = new Nodo("declaracion decimal: " + std::string($2),
                          nullptr, nullptr,
                          new Nodo("token: ';'"));
        }

    | TENTERO ID '=' expr ';'
        {
            declarar_var($2);
            guardar_var($2, atof($4->etiqueta.c_str()));
            $$ = new Nodo("declaracion+asignacion: " + std::string($2),
                          new Nodo("variable: " + std::string($2)),
                          $4,
                          new Nodo("token: '='"));
        }

    | TDECIMAL ID '=' expr ';'
        {
            declarar_var($2);
            guardar_var($2, atof($4->etiqueta.c_str()));
            $$ = new Nodo("declaracion+asignacion: " + std::string($2),
                          new Nodo("variable: " + std::string($2)),
                          $4,
                          new Nodo("token: '='"));
        }

    | ID '=' expr ';'
        {
            if (!existe_var($1))
                std::cerr << "ERROR LOGICO en linea " << num_linea
                          << ": '" << $1 << "' no fue declarada\n";
            guardar_var($1, atof($3->etiqueta.c_str()));
            printf("  %s = %.6g\n", $1, atof($3->etiqueta.c_str()));
            $$ = new Nodo("asignacion: " + std::string($1) + " =",
                          new Nodo("variable: " + std::string($1)),
                          $3,
                          new Nodo("token: '='"));
        }

    | MOSTRAR SALIDA expr ';'
        {
            printf("%.6g\n", atof($3->etiqueta.c_str()));
            $$ = new Nodo("mostrar <<",
                          $3, nullptr,
                          new Nodo("token: '<<'"));
        }

    | MOSTRAR SALIDA TEXTO ';'
        {
            char *s = $3;
            if (s[0]=='"') s++;
            char buf[256]; strncpy(buf, s, 255);
            int len = strlen(buf);
            if (buf[len-1]=='"') buf[len-1]='\0';
            printf("%s\n", buf);
            $$ = new Nodo("mostrar << \"" + std::string(buf) + "\"",
                          nullptr, nullptr,
                          new Nodo("token: '<<'"));
        }

    | MOSTRAR SALIDA ID ';'
        {
            printf("%.6g\n", obtener_var($3));
            $$ = new Nodo("mostrar << var(" + std::string($3) + ")",
                          nullptr, nullptr,
                          new Nodo("token: '<<'"));
        }

    | DATOINGRESADO ENTRADA ID ';'
        {
            if (!existe_var($3))
                std::cerr << "ERROR LOGICO en linea " << num_linea
                          << ": variable '" << $3 << "' no declarada\n";
            double val;
            printf("Ingresa valor para %s: ", $3);
            fflush(stdout);
            fscanf(stdin, "%lf", &val);
            guardar_var($3, val);
            $$ = new Nodo("datoingresado >> " + std::string($3),
                          nullptr, nullptr,
                          new Nodo("token: '>>'"));
        }

    | SI '(' cond ')' '{' programa '}'
        {
            $$ = new Nodo("si ( condicion )",
                          $3, nullptr,
                          new Nodo("token: '(' ... ')'"));
        }

    | expr ';'
        {
            printf("= %s\n", $1->etiqueta.c_str());
            $$ = new Nodo("expresion",
                          $1, nullptr,
                          new Nodo("token: ';'"));
        }
;

cond:
    expr LE expr { $$ = new Nodo("condicion: <=", $1, $3); }
    | expr GE expr { $$ = new Nodo("condicion: >=", $1, $3); }
    | expr EQ expr { $$ = new Nodo("condicion: ==", $1, $3); }
    | expr NE expr { $$ = new Nodo("condicion: !=", $1, $3); }
    | expr LT expr { $$ = new Nodo("condicion: <",  $1, $3); }
    | expr GT expr { $$ = new Nodo("condicion: >",  $1, $3); }
;

expr:
    NUM
        {
            char buf[64];
            snprintf(buf, 63, "%g", $1);
            $$ = new Nodo(std::string(buf));
        }
    | ID
        {
            if (!existe_var($1))
                std::cerr << "ERROR LOGICO en linea " << num_linea
                          << ": variable '" << $1 << "' no identificada\n";
            char buf[64];
            snprintf(buf, 63, "var(%s)=%g", $1, obtener_var($1));
            $$ = new Nodo(std::string(buf));
        }
    | expr '+' expr
        {
            $$ = new Nodo("expr: +", $1, $3, new Nodo("token: '+'"));
        }
    | expr '-' expr
        {
            $$ = new Nodo("expr: -", $1, $3, new Nodo("token: '-'"));
        }
    | expr '*' expr
        {
            $$ = new Nodo("expr: *", $1, $3, new Nodo("token: '*'"));
        }
    | expr '/' expr
        {
            $$ = new Nodo("expr: /", $1, $3, new Nodo("token: '/'"));
        }
    | '(' expr ')'
        {
            $$ = new Nodo("agrupacion",
                          new Nodo("token: '('"),
                          $2,
                          new Nodo("token: ')'"));
        }
;

%%

int main() {
    std::cout << "=== COMPILADOR LISTO ===\n";
    std::cout << "Escribe tu codigo y presiona Ctrl+D al finalizar:\n\n";
    yyparse();
    return 0;
}